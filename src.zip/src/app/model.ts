export interface Attendence {
    EmpId: number ,
     EmpName: string,
    Designation: string ,
    Date: Date ,
    Status: string,
     LoginTime: Date,
    LogoutTime: Date,
     Hours: Date,
     month: string
 
   }