import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { SupabaseService } from '../service/supabase.service';
@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent {
  loginForm: FormGroup;
  invalidCredentials: boolean = false;
  constructor(private formBuilder: FormBuilder,private router: Router, private auth: SupabaseService) {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [
        Validators.required,
        Validators.minLength(6),
        Validators.pattern(/^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9a-zA-Z]).{6,}$/)
      ]]   
     });
  }
  
  onSubmit() {
    debugger
      this.auth.signIn(this.loginForm.value.email,this.loginForm.value.password)
      .then(async(res) => {
       console.log(res);
       if(res.data.user!.role==="authenticated"){
        await this.getUserDetailsAndNavigate();
        
       }
      })
      .catch((err) =>{
       console.log(err);
       this.invalidCredentials = true;
      //  alert('Something went wrong!please try again.');
      });
     }
     private async getUserDetailsAndNavigate() {
 
      const userDetails = await this.auth.getUserDetails();
   
      if (userDetails) {
        console.log(userDetails);
        this.router.navigate(['/Dashboard']);
      } else {
   
      }
    }
 } 
  


